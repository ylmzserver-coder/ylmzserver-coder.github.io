/* LUMIO - AI istemci katmanı. Eski geminiApiCagir(payload) yerine geçer; anahtar tarayıcıda TUTULMAZ. */
const AI_ENDPOINT = '/.netlify/functions/gemini';

function aiRizaVarMi() {
  try {
    if (typeof aktifLisansKodu === 'undefined' || !aktifLisansKodu) return true;
    return localStorage.getItem('lumio_ai_riza_' + aktifLisansKodu) === '1';
  } catch (_) { return true; }
}

async function geminiApiCagir(payload) {
  if (!aiRizaVarMi()) {
    throw new Error('Yapay zeka için açık rıza verilmedi. Ayarlardan veya yeniden girişte rıza kutusunu işaretleyin. / AI consent was not given.');
  }
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), 45000);
  try {
    const r = await fetch(AI_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payload }),
      signal: c.signal
    });
    let d = {};
    try { d = await r.json(); } catch (_) {}
    if (!r.ok || !d.metin) throw new Error(d.hata || ('Yapay zeka yanıt vermedi (HTTP ' + r.status + ')'));
    return d.metin;
  } catch (e) {
    throw new Error(e.name === 'AbortError' ? 'Yapay zeka zaman aşımına uğradı.' : e.message);
  } finally { clearTimeout(t); }
}

/* Model çıktısından güvenli JSON çıkar (```json sarmalayıcı veya fazladan yazı olsa da) */
function aiJsonAyikla(ham) {
  const s = String(ham || '').replace(/```json/gi, '').replace(/```/g, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('Yapay zeka geçerli JSON döndürmedi.');
  return JSON.parse(s.slice(a, b + 1));
}

/* HTML kaçışı: yapay zeka/müşteri metni innerHTML'e girmeden önce */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function guvenliUrl(u) { return /^https?:\/\//i.test(String(u || '')) ? String(u) : '#'; }

/* Yapay zekadan gelen randevu alanlarını doğrula */
function aiRandevuDogrula(c, bugunStr) {
  const saat = /^([01]?\d|2[0-3]):[0-5]\d$/.test(c.saat || '') ? c.saat.padStart(5, '0') : '14:00';
  const tarih = /^\d{2}\.\d{2}\.\d{4}$/.test(c.tarih || '') ? c.tarih : bugunStr;
  const sure = [15, 30, 45, 60, 90, 120, 150, 180].includes(parseInt(c.sure)) ? parseInt(c.sure) : 60;
  return { saat, tarih, sure };
}

function fiyatParse(v) {
  let s = String(v == null ? '' : v).trim().replace(/\s/g, '');
  if (s.includes(',') && s.includes('.')) s = (s.lastIndexOf(',') > s.lastIndexOf('.')) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  else if (s.includes(',')) s = s.replace(',', '.');
  return parseFloat(s) || 0;
}
